package com.OrderApplicarion.config;

public class AppConstants {

	
	
	
	public static final Integer NORMAL_USER = 502;
	public static final Integer Admin_USER=501;
	
}
